import { Fragment } from "react";
import { Container } from "@mui/material";
import TaskList from "./components/tasks/TaskList";

function App() {
  const tasks = [
    {
      id: 1,
      title: "title 1",
      completed: false,
    },
    {
      id: 2,
      title: "title 2",
      completed: false,
    },
    {
      id: 3,
      title: "title 3",
      completed: false,
    },
    {
      id: 4,
      title: "title 4",
      completed: true,
    },
  ];

  return (
    <Fragment>
      <Container>
        <TaskList tasks={tasks} />
      </Container>
    </Fragment>
  );
}

export default App;
