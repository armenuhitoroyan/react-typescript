import { Task } from "./Task";

export interface TaskListProps {
  tasks: Task[];
}
